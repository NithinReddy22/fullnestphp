/**
 * routing all .php file
 */
const matchPhpFile = /.+\.php$/;



module.exports = {
    matchPhpFile
}     
