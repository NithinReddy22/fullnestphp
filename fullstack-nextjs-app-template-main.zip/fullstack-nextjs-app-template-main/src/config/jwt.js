const privateKey = 'abC123!';

export default privateKey;
