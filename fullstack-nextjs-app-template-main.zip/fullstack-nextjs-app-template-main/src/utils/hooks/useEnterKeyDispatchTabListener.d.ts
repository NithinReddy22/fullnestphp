export default useEnterKeyDispatchTabListener;
declare function useEnterKeyDispatchTabListener({ el, ctrl, system }: {
    el?: string;
    ctrl?: boolean;
    system?: string;
}): void;
