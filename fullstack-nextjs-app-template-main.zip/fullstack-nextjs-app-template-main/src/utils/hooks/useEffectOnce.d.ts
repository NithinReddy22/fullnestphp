export default useEffectOnce;
declare function useEffectOnce(effect: any): void;
