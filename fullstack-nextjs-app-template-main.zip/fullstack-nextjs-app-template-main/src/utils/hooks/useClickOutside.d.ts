export default useClickOutside;
declare function useClickOutside({ enabled, isOutside, handle, spyElement }: {
    enabled: any;
    isOutside: any;
    handle: any;
    spyElement: any;
}, deps: any): void;
