export default useNetworkStatus;
declare function useNetworkStatus(): {
    isOnline: boolean;
};
