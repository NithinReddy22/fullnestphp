export default useEnterKeyListener;
declare function useEnterKeyListener({ el, ctrl, alt, system }: {
    el: any;
    ctrl?: boolean;
    alt?: boolean;
    system?: string;
}): void;
