export default useSpaceKeyListener;
declare function useSpaceKeyListener({ el, alt, system }: {
    el: any;
    alt?: boolean;
    system?: string;
}): void;
