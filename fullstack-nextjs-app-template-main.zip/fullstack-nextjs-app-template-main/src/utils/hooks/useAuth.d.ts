export default useAuth;
declare function useAuth(): any;
