export function debounce(fn: any, limit?: number): () => void;
export function throttle(fn: any, limit?: number): (...args: any[]) => void;
