/**
 * Import the style inside
 * @param {String} id
 * @param {String} url
 * @returns
 */
export function addStyle(id: string, url: string): void;
export function removeStyle(id: any): void;
