/**
 * Match all files URLs from string
 *
 * @param {String} str Input text
 * @return {Array} All matching files
 */
export function matchAllFilesUrls(str: string): any[];
