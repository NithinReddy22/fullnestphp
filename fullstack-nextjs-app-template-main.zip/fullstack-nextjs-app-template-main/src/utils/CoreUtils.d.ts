declare const CoreUtils: any;
export default CoreUtils;
